const CHECK_INTERVAL = 60 * 1000; // 1分ごとにチェック

let todos = [];
let notifyDays = 0;
let notifyHours = 24;
let notifyMins = 0;
let notifyEnabled = false;
let notifiedIds = new Set();

// ページからメッセージを受信
self.addEventListener('message', (event) => {
  if (event.data.type === 'UPDATE_TODOS') {
    todos = event.data.todos || [];
    notifyDays = event.data.notifyDays || 0;
    notifyHours = event.data.notifyHours || 24;
    notifyMins = event.data.notifyMins || 0;
    notifyEnabled = event.data.notifyEnabled || false;
    console.log('[SW] データ更新:', todos.length, '件');
  }
});

// 定期チェック
function checkAndNotify() {
  if (!notifyEnabled || todos.length === 0) return;

  const now = Date.now();
  const totalMs = (notifyDays * 24 * 60 + notifyHours * 60 + notifyMins) * 60000;
  const label = [
    notifyDays ? `${notifyDays}日` : '',
    notifyHours ? `${notifyHours}時間` : '',
    notifyMins ? `${notifyMins}分` : ''
  ].filter(Boolean).join('') || '0分';

  for (const t of todos) {
    const fireAt = t.due - totalMs;
    // 通知タイミングの前後1分以内なら通知（1分ごとのチェックに対応）
    if (fireAt <= now + 60000 && fireAt > now - 60000) {
      if (!notifiedIds.has(t.id)) {
        notifiedIds.add(t.id);
        self.registration.showNotification('課題の期限が近づいています', {
          body: `「${t.title}」(${t.courseName}) まであと${label}`,
          icon: 'https://ssl.gstatic.com/classroom/favicon.png',
          badge: 'https://ssl.gstatic.com/classroom/favicon.png',
          tag: t.id,
          requireInteraction: true
        });
      }
    }
  }
}

// 通知クリックでアプリを開く
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then(clientList => {
      for (const client of clientList) {
        if (client.url.includes('classroom-todo') && 'focus' in client) {
          return client.focus();
        }
      }
      return clients.openWindow('./classroom-todo.html');
    })
  );
});

// インストール・アクティベート
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

// 定期チェックを開始
setInterval(checkAndNotify, CHECK_INTERVAL);
